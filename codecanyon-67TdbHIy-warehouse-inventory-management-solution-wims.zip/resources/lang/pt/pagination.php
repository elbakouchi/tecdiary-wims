<?php

return [
    'next'     => 'Próxima &raquo;',
    'previous' => '&laquo; Anterior',
];
