## Warehouse Inventory Management Solution (WIMS)

WIMS (Warehouse Inventory Management Solution) is developed to provide easy and affordable solution for managing godown/warehouse inventory/stock. It has the option to categorize the items, assign unit of measurement and manage inventory for item variants too. Yes, you can manage multiple warehouses.
